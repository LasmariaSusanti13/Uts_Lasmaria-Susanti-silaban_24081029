
package com.example.uts_lasmariasusantisilaban;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class PetunjukActivityLasmaria extends AppCompatActivity {

    Button btnKembaliPetunjuk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_petunjuk_lasmaria);

        btnKembaliPetunjuk = findViewById(R.id.btnKembaliPetunjuk);

        btnKembaliPetunjuk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
