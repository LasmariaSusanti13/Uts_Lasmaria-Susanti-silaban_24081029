package com.example.uts_lasmariasusantisilaban;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TentangActivityLasmaria extends AppCompatActivity {

    Button btnKembaliTentang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tentang_lasmaria);

        btnKembaliTentang =
                findViewById(R.id.btnKembaliTentang);

        btnKembaliTentang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}