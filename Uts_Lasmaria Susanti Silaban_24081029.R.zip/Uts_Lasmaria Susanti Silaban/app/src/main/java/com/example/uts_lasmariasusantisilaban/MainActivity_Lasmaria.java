
package com.example.uts_lasmariasusantisilaban;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity_Lasmaria extends AppCompatActivity {

    View btnGaji;
    View btnPetunjuk;
    View btnTentang;
    View btnExit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_lasmaria);

        // Menghubungkan tombol dengan XML
        btnGaji = findViewById(R.id.btnGaji);
        btnPetunjuk = findViewById(R.id.btnPetunjuk);
        btnTentang = findViewById(R.id.btnTentang);
        btnExit = findViewById(R.id.btnExit);

        // MENU GAJI
        btnGaji.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity_Lasmaria.this,
                    GajiActivityLasmaria.class
            );
            startActivity(intent);
        });

        // MENU PETUNJUK
        btnPetunjuk.setOnClickListener(v -> {
            Toast.makeText(
                    MainActivity_Lasmaria.this,
                    "Selamat datang di aplikasi Gaji Karyawan Lasmaria",
                    Toast.LENGTH_LONG
            ).show();
        });

        // MENU TENTANG
        btnTentang.setOnClickListener(v -> {
            Intent intent = new Intent(
                    MainActivity_Lasmaria.this,
                    TentangActivityLasmaria.class
            );
            startActivity(intent);
        });

        // MENU KELUAR
        btnExit.setOnClickListener(v -> {
            finishAffinity();
        });
    }
}
